<?php
namespace App\Models\jwt;

use UnexpectedValueException;

class BeforeValidException extends UnexpectedValueException
{
}
