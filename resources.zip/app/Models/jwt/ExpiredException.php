<?php
namespace App\Models\jwt;

use UnexpectedValueException;

class ExpiredException extends UnexpectedValueException
{
}
