<?php
namespace App\Models\jwt;
use UnexpectedValueException;

class SignatureInvalidException extends UnexpectedValueException
{
}
