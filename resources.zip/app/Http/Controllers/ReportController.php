<?php

namespace App\Http\Controllers;

use App\Http\Resources\Student\StudentPaymentBillCollection;
use App\Models\StudentBillPayment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    //
}
