<template>
    <footer class="footer">
        <strong>Copyright &copy; {{ new Date().getFullYear() }}
<!--            <a href="javascript:" title="Advance Management System" target="_blank">MDP</a>-->
        </strong>
        Developed by MIS
    </footer>
</template>
