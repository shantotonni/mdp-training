export default {
    me(state) {
        return state.me;
    },
}
