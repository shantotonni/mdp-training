import {baseurl} from '../base_url'
export default{
    submitButtonLoadingStatus({commit},payload){
        //console.log(payload)
    },
}
